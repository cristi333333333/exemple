# Centru de Instruire – Sistem de Evidență

Aplicație desktop **JavaFX + MySQL** pentru gestionarea cursanților, cursurilor și înscrierilor.

---

## Cerințe sistem

| Componentă | Versiune minimă |
|------------|----------------|
| JDK        | 17+            |
| Maven      | 3.8+           |
| MySQL      | 8.0+           |

---

## Configurare baza de date

1. Pornește MySQL Server
2. Rulează scriptul SQL:
```bash
mysql -u root -p < database.sql
```
3. Deschide `src/main/java/com/centru/util/DatabaseConnection.java`
4. Modifică credențialele dacă e nevoie:
```java
private static final String USER = "root";
private static final String PASS = "";   // <-- parola ta
```

---

## Rulare

```bash
mvn javafx:run
```

Sau compilează și rulează JAR:
```bash
mvn package
java --module-path /path/to/javafx-sdk/lib --add-modules javafx.controls,javafx.fxml -jar target/CentruInstruire-1.0.jar
```

---

## Funcționalități implementate

### Obligatorii ✅
| Nr | Cerință |
|----|---------|
| 1  | Proiectarea și popularea BD (6 cursanți, 6 cursuri, 10 înscrieri) |
| 2  | Interfață clară cu navigare prin tab-uri |
| 3  | Gestionarea cursanților (CRUD + căutare după nume/email) |
| 4  | Gestionarea cursurilor (CRUD + filtrare după formator/durată) |
| 5  | Gestionarea înscrierilor (adăugare, actualizare status, anulare) |
| 6  | Raport sumar (nume, nr. înscrieri, sumă achitată) |
| 7  | Validare date și tratare erori |

### Bonus ⭐
| Nr | Cerință |
|----|---------|
| B1 | Raportul este sortat descrescător după suma achitată |
| B2 | Statistici generale (total cursanți, total încasat, medie/cursant, curs top) |
| B3 | Export raport în TXT și CSV |
| B4 | Email unic (validare duplicat), format telefon validat |
| B5 | Restricție: cursantul nu poate fi înscris de 2 ori la același curs |

---

## Structura proiectului

```
CentruInstruire/
├── database.sql                        # Script SQL (schema + date test)
├── pom.xml                             # Dependențe Maven
└── src/main/java/com/centru/
    ├── MainApp.java                    # Entry point JavaFX
    ├── model/
    │   ├── Cursant.java
    │   ├── Curs.java
    │   ├── Inscriere.java
    │   └── RaportRow.java
    ├── dao/
    │   ├── CursantDAO.java
    │   ├── CursDAO.java
    │   └── InscriereDAO.java
    ├── ui/
    │   ├── MainController.java
    │   ├── CursantiView.java
    │   ├── CursuriView.java
    │   ├── InscrieriView.java
    │   └── RaportView.java
    └── util/
        ├── DatabaseConnection.java
        ├── AlertHelper.java
        └── Validator.java
```

---

## Note pentru candidat

- Modifică **USER** și **PASS** în `DatabaseConnection.java` conform configurației tale MySQL
- Baza de date se numește `centru_instruire` (creată automat de scriptul SQL)
- Fișierele TXT/CSV exportate se salvează în directorul de unde rulezi aplicația
