-- ============================================================
-- Sistem de evidenta a cursurilor si inscrierilor
-- Centru de instruire - Script SQL
-- ============================================================

CREATE DATABASE IF NOT EXISTS centru_instruire
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE centru_instruire;

-- ============================================================
-- TABELE
-- ============================================================

CREATE TABLE IF NOT EXISTS Cursant (
    IdCursant   INT AUTO_INCREMENT PRIMARY KEY,
    Nume        VARCHAR(50)  NOT NULL,
    Prenume     VARCHAR(50)  NOT NULL,
    Telefon     VARCHAR(20)  NOT NULL,
    Email       VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS Curs (
    IdCurs      INT AUTO_INCREMENT PRIMARY KEY,
    Denumire    VARCHAR(100) NOT NULL,
    Formator    VARCHAR(100) NOT NULL,
    Pret        DECIMAL(10,2) NOT NULL CHECK (Pret > 0),
    DurataZile  INT NOT NULL CHECK (DurataZile > 0)
);

CREATE TABLE IF NOT EXISTS Inscriere (
    IdInscriere     INT AUTO_INCREMENT PRIMARY KEY,
    IdCursant       INT NOT NULL,
    IdCurs          INT NOT NULL,
    DataInscriere   DATE NOT NULL,
    StatusPlata     ENUM('Achitat','In asteptare','Anulat') NOT NULL DEFAULT 'In asteptare',
    FOREIGN KEY (IdCursant) REFERENCES Cursant(IdCursant) ON DELETE CASCADE,
    FOREIGN KEY (IdCurs)    REFERENCES Curs(IdCurs) ON DELETE CASCADE,
    UNIQUE KEY uq_cursant_curs (IdCursant, IdCurs)
);

-- ============================================================
-- DATE DE TEST
-- ============================================================

INSERT INTO Cursant (Nume, Prenume, Telefon, Email) VALUES
('Popescu',   'Ion',      '060123456', 'ion.popescu@email.md'),
('Rusu',      'Maria',    '061234567', 'maria.rusu@email.md'),
('Ionescu',   'Andrei',   '062345678', 'andrei.ionescu@email.md'),
('Cojocaru',  'Elena',    '063456789', 'elena.cojocaru@email.md'),
('Botnaru',   'Victor',   '064567890', 'victor.botnaru@email.md'),
('Lungu',     'Cristina', '065678901', 'cristina.lungu@email.md');

INSERT INTO Curs (Denumire, Formator, Pret, DurataZile) VALUES
('Java Fundamentals',     'Prof. Gheorghe',  1500.00, 30),
('Web Development',       'Prof. Irina',     1800.00, 45),
('Baze de Date SQL',      'Prof. Mihai',     1200.00, 20),
('Python for Beginners',  'Prof. Natalia',   1300.00, 25),
('Cybersecurity Basics',  'Prof. Alexandru', 2000.00, 60),
('Mobile Development',    'Prof. Tatiana',   1700.00, 40);

INSERT INTO Inscriere (IdCursant, IdCurs, DataInscriere, StatusPlata) VALUES
(1, 1, '2026-01-10', 'Achitat'),
(1, 3, '2026-01-15', 'Achitat'),
(2, 2, '2026-01-12', 'Achitat'),
(2, 4, '2026-02-01', 'In asteptare'),
(3, 1, '2026-01-20', 'Achitat'),
(3, 5, '2026-01-22', 'In asteptare'),
(4, 2, '2026-02-05', 'Achitat'),
(5, 3, '2026-02-10', 'Achitat'),
(5, 6, '2026-02-12', 'In asteptare'),
(6, 4, '2026-02-15', 'Achitat');
