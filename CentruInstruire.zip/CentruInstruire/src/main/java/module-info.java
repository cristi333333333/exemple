module com.centru {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    exports com.centru;
    exports com.centru.ui;
    exports com.centru.model;
    exports com.centru.dao;
    exports com.centru.util;

    opens com.centru.model to javafx.base;
    opens com.centru.ui    to javafx.fxml;
}
