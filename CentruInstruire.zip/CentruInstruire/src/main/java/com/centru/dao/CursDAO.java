package com.centru.dao;

import com.centru.model.Curs;
import com.centru.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CursDAO {

    public List<Curs> getAll() throws SQLException {
        List<Curs> list = new ArrayList<>();
        String sql = "SELECT * FROM Curs ORDER BY Denumire";
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public List<Curs> filter(String formator, Integer durataMax) throws SQLException {
        List<Curs> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT * FROM Curs WHERE 1=1");
        if (formator != null && !formator.isBlank()) sql.append(" AND Formator LIKE ?");
        if (durataMax != null && durataMax > 0) sql.append(" AND DurataZile <= ?");
        sql.append(" ORDER BY Denumire");

        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql.toString())) {
            int idx = 1;
            if (formator != null && !formator.isBlank()) ps.setString(idx++, "%" + formator + "%");
            if (durataMax != null && durataMax > 0) ps.setInt(idx, durataMax);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    public void insert(Curs c) throws SQLException {
        String sql = "INSERT INTO Curs (Denumire, Formator, Pret, DurataZile) VALUES (?,?,?,?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, c.getDenumire());
            ps.setString(2, c.getFormator());
            ps.setDouble(3, c.getPret());
            ps.setInt(4, c.getDurataZile());
            ps.executeUpdate();
        }
    }

    public void update(Curs c) throws SQLException {
        String sql = "UPDATE Curs SET Denumire=?, Formator=?, Pret=?, DurataZile=? WHERE IdCurs=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, c.getDenumire());
            ps.setString(2, c.getFormator());
            ps.setDouble(3, c.getPret());
            ps.setInt(4, c.getDurataZile());
            ps.setInt(5, c.getIdCurs());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM Curs WHERE IdCurs=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private Curs map(ResultSet rs) throws SQLException {
        return new Curs(
            rs.getInt("IdCurs"),
            rs.getString("Denumire"),
            rs.getString("Formator"),
            rs.getDouble("Pret"),
            rs.getInt("DurataZile")
        );
    }
}
