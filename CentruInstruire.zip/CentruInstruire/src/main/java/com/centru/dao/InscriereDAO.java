package com.centru.dao;

import com.centru.model.Inscriere;
import com.centru.model.RaportRow;
import com.centru.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InscriereDAO {

    public List<Inscriere> getAll() throws SQLException {
        List<Inscriere> list = new ArrayList<>();
        String sql = """
            SELECT i.*, CONCAT(c.Nume,' ',c.Prenume) AS NumeCursant,
                   cu.Denumire AS DenumireCurs, cu.Pret
            FROM Inscriere i
            JOIN Cursant c  ON c.IdCursant = i.IdCursant
            JOIN Curs cu    ON cu.IdCurs   = i.IdCurs
            ORDER BY i.DataInscriere DESC
            """;
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapFull(rs));
        }
        return list;
    }

    public List<Inscriere> getByCursant(int idCursant) throws SQLException {
        List<Inscriere> list = new ArrayList<>();
        String sql = """
            SELECT i.*, CONCAT(c.Nume,' ',c.Prenume) AS NumeCursant,
                   cu.Denumire AS DenumireCurs, cu.Pret
            FROM Inscriere i
            JOIN Cursant c  ON c.IdCursant = i.IdCursant
            JOIN Curs cu    ON cu.IdCurs   = i.IdCurs
            WHERE i.IdCursant = ?
            ORDER BY i.DataInscriere DESC
            """;
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idCursant);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapFull(rs));
            }
        }
        return list;
    }

    public void insert(Inscriere ins) throws SQLException {
        String sql = "INSERT INTO Inscriere (IdCursant, IdCurs, DataInscriere, StatusPlata) VALUES (?,?,?,?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, ins.getIdCursant());
            ps.setInt(2, ins.getIdCurs());
            ps.setDate(3, Date.valueOf(ins.getDataInscriere()));
            ps.setString(4, ins.getStatusPlata());
            ps.executeUpdate();
        }
    }

    public void updateStatus(int idInscriere, String status) throws SQLException {
        String sql = "UPDATE Inscriere SET StatusPlata=? WHERE IdInscriere=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, idInscriere);
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM Inscriere WHERE IdInscriere=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public boolean exists(int idCursant, int idCurs) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Inscriere WHERE IdCursant=? AND IdCurs=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, idCursant);
            ps.setInt(2, idCurs);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    public List<RaportRow> getRaport() throws SQLException {
        List<RaportRow> list = new ArrayList<>();
        String sql = """
            SELECT CONCAT(c.Nume,' ',c.Prenume) AS NumeComplet,
                   COUNT(i.IdInscriere) AS NrInscrieri,
                   COALESCE(SUM(CASE WHEN i.StatusPlata='Achitat' THEN cu.Pret ELSE 0 END), 0) AS SumaAchitata
            FROM Cursant c
            LEFT JOIN Inscriere i ON i.IdCursant = c.IdCursant
            LEFT JOIN Curs cu     ON cu.IdCurs   = i.IdCurs
            GROUP BY c.IdCursant, c.Nume, c.Prenume
            ORDER BY SumaAchitata DESC
            """;
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new RaportRow(
                    rs.getString("NumeComplet"),
                    rs.getInt("NrInscrieri"),
                    rs.getDouble("SumaAchitata")
                ));
            }
        }
        return list;
    }

    // Bonus: statistici generale
    public String getStatistici() throws SQLException {
        String sql = """
            SELECT
              (SELECT COUNT(*) FROM Cursant) AS totalCursanti,
              (SELECT COALESCE(SUM(cu.Pret),0) FROM Inscriere i JOIN Curs cu ON cu.IdCurs=i.IdCurs WHERE i.StatusPlata='Achitat') AS totalIncasat,
              (SELECT Denumire FROM Curs c JOIN Inscriere i ON i.IdCurs=c.IdCurs GROUP BY c.IdCurs ORDER BY COUNT(*) DESC LIMIT 1) AS cursCelMaiInscris
            """;
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) {
                int total = rs.getInt("totalCursanti");
                double inc = rs.getDouble("totalIncasat");
                String top = rs.getString("cursCelMaiInscris");
                double medie = total > 0 ? inc / total : 0;
                return String.format(
                    "Total cursanți: %d\nTotal încasat: %.2f MDL\nMedia plăților/cursant: %.2f MDL\nCurs cu cele mai multe înscrieri: %s",
                    total, inc, medie, top != null ? top : "N/A"
                );
            }
        }
        return "";
    }

    private Inscriere mapFull(ResultSet rs) throws SQLException {
        Inscriere i = new Inscriere(
            rs.getInt("IdInscriere"),
            rs.getInt("IdCursant"),
            rs.getInt("IdCurs"),
            rs.getDate("DataInscriere").toLocalDate(),
            rs.getString("StatusPlata")
        );
        i.setNumeCursant(rs.getString("NumeCursant"));
        i.setDenumireCurs(rs.getString("DenumireCurs"));
        i.setPretCurs(rs.getDouble("Pret"));
        return i;
    }
}
