package com.centru.dao;

import com.centru.model.Cursant;
import com.centru.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CursantDAO {

    public List<Cursant> getAll() throws SQLException {
        List<Cursant> list = new ArrayList<>();
        String sql = "SELECT * FROM Cursant ORDER BY Nume, Prenume";
        try (Statement st = DatabaseConnection.getConnection().createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public List<Cursant> search(String keyword) throws SQLException {
        List<Cursant> list = new ArrayList<>();
        String sql = "SELECT * FROM Cursant WHERE CONCAT(Nume,' ',Prenume) LIKE ? OR Email LIKE ? ORDER BY Nume";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, "%" + keyword + "%");
            ps.setString(2, "%" + keyword + "%");
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    public void insert(Cursant c) throws SQLException {
        String sql = "INSERT INTO Cursant (Nume, Prenume, Telefon, Email) VALUES (?,?,?,?)";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, c.getNume());
            ps.setString(2, c.getPrenume());
            ps.setString(3, c.getTelefon());
            ps.setString(4, c.getEmail());
            ps.executeUpdate();
        }
    }

    public void update(Cursant c) throws SQLException {
        String sql = "UPDATE Cursant SET Nume=?, Prenume=?, Telefon=?, Email=? WHERE IdCursant=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, c.getNume());
            ps.setString(2, c.getPrenume());
            ps.setString(3, c.getTelefon());
            ps.setString(4, c.getEmail());
            ps.setInt(5, c.getIdCursant());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM Cursant WHERE IdCursant=?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public boolean emailExists(String email, int excludeId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM Cursant WHERE Email=? AND IdCursant<>?";
        try (PreparedStatement ps = DatabaseConnection.getConnection().prepareStatement(sql)) {
            ps.setString(1, email);
            ps.setInt(2, excludeId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    private Cursant map(ResultSet rs) throws SQLException {
        return new Cursant(
            rs.getInt("IdCursant"),
            rs.getString("Nume"),
            rs.getString("Prenume"),
            rs.getString("Telefon"),
            rs.getString("Email")
        );
    }
}
