package com.centru.ui;

import com.centru.dao.CursantDAO;
import com.centru.model.Cursant;
import com.centru.util.AlertHelper;
import com.centru.util.Validator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.sql.SQLException;
import java.util.List;

public class CursantiView {

    private final CursantDAO dao = new CursantDAO();
    private final ObservableList<Cursant> data = FXCollections.observableArrayList();
    private final TableView<Cursant> table = new TableView<>(data);

    private final TextField tfNume    = new TextField();
    private final TextField tfPrenume = new TextField();
    private final TextField tfTelefon = new TextField();
    private final TextField tfEmail   = new TextField();
    private final TextField tfSearch  = new TextField();

    private Cursant selected;
    private final BorderPane root = new BorderPane();

    public CursantiView() {
        build();
        loadData(null);
    }

    @SuppressWarnings("unchecked")
    private void build() {
        // --- Table ---
        TableColumn<Cursant, Integer> colId     = col("ID",      "idCursant",  60);
        TableColumn<Cursant, String>  colNume   = col("Nume",    "nume",      150);
        TableColumn<Cursant, String>  colPren   = col("Prenume", "prenume",   150);
        TableColumn<Cursant, String>  colTel    = col("Telefon", "telefon",   130);
        TableColumn<Cursant, String>  colEmail  = col("Email",   "email",     220);
        table.getColumns().addAll(colId, colNume, colPren, colTel, colEmail);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.getStyleClass().add("data-table");
        table.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> populate(n));

        // --- Search bar ---
        tfSearch.setPromptText("Caută după nume sau email...");
        tfSearch.setPrefWidth(280);
        Button btnSearch = new Button("🔍 Caută");
        btnSearch.getStyleClass().add("btn-search");
        Button btnReset = new Button("✕ Reset");
        btnReset.getStyleClass().add("btn-secondary");
        btnSearch.setOnAction(e -> loadData(tfSearch.getText()));
        btnReset.setOnAction(e -> { tfSearch.clear(); loadData(null); });
        tfSearch.setOnAction(e -> loadData(tfSearch.getText()));

        HBox searchBar = new HBox(8, new Label("🔎"), tfSearch, btnSearch, btnReset);
        searchBar.setAlignment(Pos.CENTER_LEFT);
        searchBar.setPadding(new Insets(10, 12, 10, 12));
        searchBar.getStyleClass().add("search-bar");

        VBox tableBox = new VBox(0, searchBar, table);
        VBox.setVgrow(table, Priority.ALWAYS);

        // --- Form ---
        GridPane form = new GridPane();
        form.setHgap(10); form.setVgap(10);
        form.setPadding(new Insets(16));

        tfNume.setPromptText("Nume");
        tfPrenume.setPromptText("Prenume");
        tfTelefon.setPromptText("06XXXXXXX");
        tfEmail.setPromptText("exemplu@email.md");

        form.add(label("Nume *"),    0, 0); form.add(tfNume,    1, 0);
        form.add(label("Prenume *"), 0, 1); form.add(tfPrenume, 1, 1);
        form.add(label("Telefon *"), 0, 2); form.add(tfTelefon, 1, 2);
        form.add(label("Email *"),   0, 3); form.add(tfEmail,   1, 3);

        tfNume.setPrefWidth(200); tfPrenume.setPrefWidth(200);
        tfTelefon.setPrefWidth(200); tfEmail.setPrefWidth(200);

        Button btnAdd    = new Button("➕ Adaugă");
        Button btnUpdate = new Button("✏️ Salvează");
        Button btnDelete = new Button("🗑️ Șterge");
        Button btnClear  = new Button("🧹 Curăță");

        btnAdd.getStyleClass().add("btn-primary");
        btnUpdate.getStyleClass().add("btn-warning");
        btnDelete.getStyleClass().add("btn-danger");
        btnClear.getStyleClass().add("btn-secondary");

        btnAdd.setOnAction(e -> addCursant());
        btnUpdate.setOnAction(e -> updateCursant());
        btnDelete.setOnAction(e -> deleteCursant());
        btnClear.setOnAction(e -> clearForm());

        HBox buttons = new HBox(8, btnAdd, btnUpdate, btnDelete, btnClear);
        buttons.setPadding(new Insets(0, 0, 8, 0));

        Label formTitle = new Label("Detalii Cursant");
        formTitle.getStyleClass().add("form-title");

        VBox formBox = new VBox(12, formTitle, form, buttons);
        formBox.setPadding(new Insets(12));
        formBox.getStyleClass().add("form-panel");
        formBox.setPrefWidth(280);

        root.setCenter(tableBox);
        root.setRight(formBox);
    }

    private void loadData(String kw) {
        try {
            List<Cursant> list = (kw == null || kw.isBlank()) ? dao.getAll() : dao.search(kw);
            data.setAll(list);
        } catch (SQLException e) {
            AlertHelper.error("Eroare", e.getMessage());
        }
    }

    private void populate(Cursant c) {
        selected = c;
        if (c == null) return;
        tfNume.setText(c.getNume());
        tfPrenume.setText(c.getPrenume());
        tfTelefon.setText(c.getTelefon());
        tfEmail.setText(c.getEmail());
    }

    private void addCursant() {
        if (!validate()) return;
        try {
            if (dao.emailExists(tfEmail.getText().trim(), -1)) {
                AlertHelper.error("Validare", "Email-ul există deja!"); return;
            }
            dao.insert(buildFromForm(0));
            clearForm();
            loadData(null);
        } catch (SQLException e) {
            AlertHelper.error("Eroare BD", e.getMessage());
        }
    }

    private void updateCursant() {
        if (selected == null) { AlertHelper.error("Selecție", "Selectați un cursant!"); return; }
        if (!validate()) return;
        try {
            if (dao.emailExists(tfEmail.getText().trim(), selected.getIdCursant())) {
                AlertHelper.error("Validare", "Email-ul există deja!"); return;
            }
            Cursant c = buildFromForm(selected.getIdCursant());
            dao.update(c);
            clearForm();
            loadData(null);
        } catch (SQLException e) {
            AlertHelper.error("Eroare BD", e.getMessage());
        }
    }

    private void deleteCursant() {
        if (selected == null) { AlertHelper.error("Selecție", "Selectați un cursant!"); return; }
        if (!AlertHelper.confirm("Confirmare", "Ștergeți cursantul \"" + selected.getNumeComplet() + "\"?\n(Se vor șterge și înscrierile asociate!)")) return;
        try {
            dao.delete(selected.getIdCursant());
            clearForm();
            loadData(null);
        } catch (SQLException e) {
            AlertHelper.error("Eroare BD", e.getMessage());
        }
    }

    private boolean validate() {
        if (Validator.isBlank(tfNume.getText()))    { AlertHelper.error("Validare", "Câmpul Nume este obligatoriu!"); return false; }
        if (Validator.isBlank(tfPrenume.getText())) { AlertHelper.error("Validare", "Câmpul Prenume este obligatoriu!"); return false; }
        if (Validator.isBlank(tfTelefon.getText())) { AlertHelper.error("Validare", "Câmpul Telefon este obligatoriu!"); return false; }
        if (!Validator.isValidPhone(tfTelefon.getText())) { AlertHelper.error("Validare", "Formatul telefonului este invalid!"); return false; }
        if (!Validator.isValidEmail(tfEmail.getText()))   { AlertHelper.error("Validare", "Email-ul nu este valid!"); return false; }
        return true;
    }

    private Cursant buildFromForm(int id) {
        return new Cursant(id,
            tfNume.getText().trim(),
            tfPrenume.getText().trim(),
            tfTelefon.getText().trim(),
            tfEmail.getText().trim()
        );
    }

    private void clearForm() {
        selected = null;
        tfNume.clear(); tfPrenume.clear(); tfTelefon.clear(); tfEmail.clear();
        table.getSelectionModel().clearSelection();
    }

    private <S, T> TableColumn<S, T> col(String title, String prop, double w) {
        TableColumn<S, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        c.setPrefWidth(w);
        return c;
    }

    private Label label(String t) {
        Label l = new Label(t);
        l.getStyleClass().add("form-label");
        return l;
    }

    public Pane getView() { return root; }
}
