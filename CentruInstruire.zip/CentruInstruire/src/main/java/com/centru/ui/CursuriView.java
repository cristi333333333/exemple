package com.centru.ui;

import com.centru.dao.CursDAO;
import com.centru.model.Curs;
import com.centru.util.AlertHelper;
import com.centru.util.Validator;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.sql.SQLException;
import java.util.List;

public class CursuriView {

    private final CursDAO dao = new CursDAO();
    private final ObservableList<Curs> data = FXCollections.observableArrayList();
    private final TableView<Curs> table = new TableView<>(data);

    private final TextField tfDenumire  = new TextField();
    private final TextField tfFormator  = new TextField();
    private final TextField tfPret      = new TextField();
    private final TextField tfDurata    = new TextField();
    private final TextField tfFiltFormator = new TextField();
    private final TextField tfFiltDurata   = new TextField();

    private Curs selected;
    private final BorderPane root = new BorderPane();

    public CursuriView() {
        build();
        loadData(null, null);
    }

    @SuppressWarnings("unchecked")
    private void build() {
        TableColumn<Curs, Integer> colId    = col("ID",           "idCurs",    55);
        TableColumn<Curs, String>  colDen   = col("Denumire",     "denumire", 180);
        TableColumn<Curs, String>  colForm  = col("Formator",     "formator", 160);
        TableColumn<Curs, Double>  colPret  = col("Preț (MDL)",   "pret",      110);
        TableColumn<Curs, Integer> colDur   = col("Durata (zile)","durataZile", 110);

        colPret.setCellFactory(tc -> new TableCell<>() {
            protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : String.format("%.2f", v));
            }
        });

        table.getColumns().addAll(colId, colDen, colForm, colPret, colDur);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.getStyleClass().add("data-table");
        table.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> populate(n));

        // Filter bar
        tfFiltFormator.setPromptText("Formator...");
        tfFiltFormator.setPrefWidth(160);
        tfFiltDurata.setPromptText("Max zile...");
        tfFiltDurata.setPrefWidth(90);
        Button btnFilter = new Button("🔍 Filtrează");
        btnFilter.getStyleClass().add("btn-search");
        Button btnReset = new Button("✕ Reset");
        btnReset.getStyleClass().add("btn-secondary");

        btnFilter.setOnAction(e -> {
            Integer dur = Validator.isPositiveInt(tfFiltDurata.getText()) ? Integer.parseInt(tfFiltDurata.getText()) : null;
            loadData(tfFiltFormator.getText(), dur);
        });
        btnReset.setOnAction(e -> { tfFiltFormator.clear(); tfFiltDurata.clear(); loadData(null, null); });

        HBox filterBar = new HBox(8, new Label("Formator:"), tfFiltFormator,
                new Label("Max zile:"), tfFiltDurata, btnFilter, btnReset);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(10, 12, 10, 12));
        filterBar.getStyleClass().add("search-bar");

        VBox tableBox = new VBox(0, filterBar, table);
        VBox.setVgrow(table, Priority.ALWAYS);

        // Form
        GridPane form = new GridPane();
        form.setHgap(10); form.setVgap(10);
        form.setPadding(new Insets(16));

        tfDenumire.setPromptText("ex. Java Fundamentals");
        tfFormator.setPromptText("ex. Prof. Ion");
        tfPret.setPromptText("1500.00");
        tfDurata.setPromptText("30");

        form.add(label("Denumire *"), 0, 0); form.add(tfDenumire, 1, 0);
        form.add(label("Formator *"), 0, 1); form.add(tfFormator, 1, 1);
        form.add(label("Preț (MDL) *"), 0, 2); form.add(tfPret,  1, 2);
        form.add(label("Durata (zile) *"), 0, 3); form.add(tfDurata, 1, 3);

        tfDenumire.setPrefWidth(200); tfFormator.setPrefWidth(200);
        tfPret.setPrefWidth(200);     tfDurata.setPrefWidth(200);

        Button btnAdd    = new Button("➕ Adaugă");
        Button btnUpdate = new Button("✏️ Salvează");
        Button btnDelete = new Button("🗑️ Șterge");
        Button btnClear  = new Button("🧹 Curăță");

        btnAdd.getStyleClass().add("btn-primary");
        btnUpdate.getStyleClass().add("btn-warning");
        btnDelete.getStyleClass().add("btn-danger");
        btnClear.getStyleClass().add("btn-secondary");

        btnAdd.setOnAction(e -> addCurs());
        btnUpdate.setOnAction(e -> updateCurs());
        btnDelete.setOnAction(e -> deleteCurs());
        btnClear.setOnAction(e -> clearForm());

        HBox buttons = new HBox(8, btnAdd, btnUpdate, btnDelete, btnClear);

        Label formTitle = new Label("Detalii Curs");
        formTitle.getStyleClass().add("form-title");

        VBox formBox = new VBox(12, formTitle, form, buttons);
        formBox.setPadding(new Insets(12));
        formBox.getStyleClass().add("form-panel");
        formBox.setPrefWidth(290);

        root.setCenter(tableBox);
        root.setRight(formBox);
    }

    private void loadData(String formator, Integer durataMax) {
        try {
            List<Curs> list = (formator == null && durataMax == null)
                    ? dao.getAll() : dao.filter(formator, durataMax);
            data.setAll(list);
        } catch (SQLException e) {
            AlertHelper.error("Eroare", e.getMessage());
        }
    }

    private void populate(Curs c) {
        selected = c;
        if (c == null) return;
        tfDenumire.setText(c.getDenumire());
        tfFormator.setText(c.getFormator());
        tfPret.setText(String.format("%.2f", c.getPret()));
        tfDurata.setText(String.valueOf(c.getDurataZile()));
    }

    private void addCurs() {
        if (!validate()) return;
        try {
            dao.insert(buildFromForm(0));
            clearForm(); loadData(null, null);
        } catch (SQLException e) { AlertHelper.error("Eroare BD", e.getMessage()); }
    }

    private void updateCurs() {
        if (selected == null) { AlertHelper.error("Selecție", "Selectați un curs!"); return; }
        if (!validate()) return;
        try {
            dao.update(buildFromForm(selected.getIdCurs()));
            clearForm(); loadData(null, null);
        } catch (SQLException e) { AlertHelper.error("Eroare BD", e.getMessage()); }
    }

    private void deleteCurs() {
        if (selected == null) { AlertHelper.error("Selecție", "Selectați un curs!"); return; }
        if (!AlertHelper.confirm("Confirmare", "Ștergeți cursul \"" + selected.getDenumire() + "\"?\n(Se vor șterge și înscrierile asociate!)")) return;
        try {
            dao.delete(selected.getIdCurs());
            clearForm(); loadData(null, null);
        } catch (SQLException e) { AlertHelper.error("Eroare BD", e.getMessage()); }
    }

    private boolean validate() {
        if (Validator.isBlank(tfDenumire.getText())) { AlertHelper.error("Validare", "Denumirea este obligatorie!"); return false; }
        if (Validator.isBlank(tfFormator.getText())) { AlertHelper.error("Validare", "Formatorul este obligatoriu!"); return false; }
        if (!Validator.isPositiveDouble(tfPret.getText())) { AlertHelper.error("Validare", "Prețul trebuie să fie > 0!"); return false; }
        if (!Validator.isPositiveInt(tfDurata.getText()))  { AlertHelper.error("Validare", "Durata trebuie să fie > 0!"); return false; }
        return true;
    }

    private Curs buildFromForm(int id) {
        return new Curs(id,
            tfDenumire.getText().trim(),
            tfFormator.getText().trim(),
            Double.parseDouble(tfPret.getText()),
            Integer.parseInt(tfDurata.getText())
        );
    }

    private void clearForm() {
        selected = null;
        tfDenumire.clear(); tfFormator.clear(); tfPret.clear(); tfDurata.clear();
        table.getSelectionModel().clearSelection();
    }

    private <S, T> TableColumn<S, T> col(String title, String prop, double w) {
        TableColumn<S, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        c.setPrefWidth(w);
        return c;
    }

    private Label label(String t) {
        Label l = new Label(t);
        l.getStyleClass().add("form-label");
        return l;
    }

    public Pane getView() { return root; }
}
