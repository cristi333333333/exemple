package com.centru.ui;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;

public class MainController {

    private final BorderPane root = new BorderPane();

    public MainController() {
        build();
    }

    private void build() {
        // Header
        HBox header = new HBox();
        header.getStyleClass().add("app-header");
        header.setPadding(new Insets(12, 20, 12, 20));

        Label title = new Label("🎓 Centru de Instruire");
        title.getStyleClass().add("app-title");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label subtitle = new Label("Sistem de Evidență a Cursurilor");
        subtitle.getStyleClass().add("app-subtitle");

        header.getChildren().addAll(title, spacer, subtitle);
        root.setTop(header);

        // Tabs
        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabPane.getStyleClass().add("main-tabs");

        Tab tabCursanti   = new Tab("👥  Cursanți",   new CursantiView().getView());
        Tab tabCursuri    = new Tab("📚  Cursuri",    new CursuriView().getView());
        Tab tabInscrieri  = new Tab("📋  Înscrieri",  new InscrieriView().getView());
        Tab tabRaport     = new Tab("📊  Raport",     new RaportView().getView());

        tabPane.getTabs().addAll(tabCursanti, tabCursuri, tabInscrieri, tabRaport);
        root.setCenter(tabPane);
    }

    public BorderPane getView() {
        return root;
    }
}
