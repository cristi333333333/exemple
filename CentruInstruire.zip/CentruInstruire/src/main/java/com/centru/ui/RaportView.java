package com.centru.ui;

import com.centru.dao.InscriereDAO;
import com.centru.model.RaportRow;
import com.centru.util.AlertHelper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class RaportView {

    private final InscriereDAO dao = new InscriereDAO();
    private final ObservableList<RaportRow> data = FXCollections.observableArrayList();
    private final TableView<RaportRow> table = new TableView<>(data);
    private final Label lblStatistici = new Label();
    private final BorderPane root = new BorderPane();

    public RaportView() {
        build();
        loadRaport();
    }

    @SuppressWarnings("unchecked")
    private void build() {
        // --- Table ---
        TableColumn<RaportRow, String>  colNume  = col("Nume Complet",      "numeComplet",   260);
        TableColumn<RaportRow, Integer> colNr    = col("Nr. Înscrieri",     "nrInscrieri",   130);
        TableColumn<RaportRow, Double>  colSuma  = col("Sumă Achitată (MDL)", "sumaAchitata", 180);

        colSuma.setCellFactory(tc -> new TableCell<>() {
            protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : String.format("%.2f", v));
            }
        });

        colNr.setCellFactory(tc -> new TableCell<>() {
            protected void updateItem(Integer v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setStyle(""); return; }
                setText(String.valueOf(v));
                setStyle(v == 0 ? "-fx-text-fill: #999;" : "-fx-text-fill: #2c3e50; -fx-font-weight: bold;");
            }
        });

        table.getColumns().addAll(colNume, colNr, colSuma);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.getStyleClass().add("data-table");

        // --- Statistici box ---
        lblStatistici.getStyleClass().add("statistici-label");
        lblStatistici.setWrapText(true);
        lblStatistici.setPadding(new Insets(12));

        TitledPane statsPane = new TitledPane("📊 Statistici Generale", lblStatistici);
        statsPane.setCollapsible(false);
        statsPane.getStyleClass().add("stats-pane");

        // --- Buttons ---
        Button btnRefresh = new Button("🔄 Actualizează");
        Button btnExportTxt = new Button("💾 Export TXT");
        Button btnExportCsv = new Button("📄 Export CSV");

        btnRefresh.getStyleClass().add("btn-primary");
        btnExportTxt.getStyleClass().add("btn-search");
        btnExportCsv.getStyleClass().add("btn-secondary");

        btnRefresh.setOnAction(e -> loadRaport());
        btnExportTxt.setOnAction(e -> exportTxt());
        btnExportCsv.setOnAction(e -> exportCsv());

        HBox btnBar = new HBox(10, btnRefresh, btnExportTxt, btnExportCsv);
        btnBar.setAlignment(Pos.CENTER_LEFT);
        btnBar.setPadding(new Insets(10, 12, 10, 12));
        btnBar.getStyleClass().add("search-bar");

        Label title = new Label("📋 Raport Sumar – Participare și Plăți");
        title.getStyleClass().add("form-title");
        title.setPadding(new Insets(12, 12, 0, 12));

        VBox center = new VBox(8, title, btnBar, table);
        VBox.setVgrow(table, Priority.ALWAYS);

        VBox right = new VBox(12, statsPane);
        right.setPadding(new Insets(12));
        right.setPrefWidth(300);
        right.getStyleClass().add("form-panel");

        root.setCenter(center);
        root.setRight(right);
    }

    private void loadRaport() {
        try {
            List<RaportRow> rows = dao.getRaport();
            data.setAll(rows);
            String stats = dao.getStatistici();
            lblStatistici.setText(stats);
        } catch (SQLException e) {
            AlertHelper.error("Eroare", e.getMessage());
        }
    }

    private void exportTxt() {
        if (data.isEmpty()) { AlertHelper.info("Export", "Nu există date de exportat."); return; }
        String filename = "raport_" + LocalDate.now() + ".txt";
        try (FileWriter fw = new FileWriter(filename)) {
            fw.write("=" .repeat(55) + "\n");
            fw.write("  RAPORT SUMAR – CENTRU DE INSTRUIRE\n");
            fw.write("  Data: " + LocalDate.now() + "\n");
            fw.write("=" .repeat(55) + "\n\n");
            fw.write(String.format("%-30s %10s %14s%n", "Nume Complet", "Înscrieri", "Sumă (MDL)"));
            fw.write("-".repeat(55) + "\n");
            for (RaportRow r : data) {
                fw.write(String.format("%-30s %10d %14.2f%n",
                        r.getNumeComplet(), r.getNrInscrieri(), r.getSumaAchitata()));
            }
            fw.write("\n" + "=".repeat(55) + "\n");
            fw.write(lblStatistici.getText() + "\n");
            AlertHelper.info("Export reușit", "Raportul a fost salvat: " + filename);
        } catch (IOException e) {
            AlertHelper.error("Eroare export", e.getMessage());
        }
    }

    private void exportCsv() {
        if (data.isEmpty()) { AlertHelper.info("Export", "Nu există date de exportat."); return; }
        String filename = "raport_" + LocalDate.now() + ".csv";
        try (FileWriter fw = new FileWriter(filename)) {
            fw.write("Nume Complet,Nr. Inscrieri,Suma Achitata (MDL)\n");
            for (RaportRow r : data) {
                fw.write(String.format("%s,%d,%.2f%n",
                        r.getNumeComplet(), r.getNrInscrieri(), r.getSumaAchitata()));
            }
            AlertHelper.info("Export reușit", "CSV salvat: " + filename);
        } catch (IOException e) {
            AlertHelper.error("Eroare export", e.getMessage());
        }
    }

    private <S, T> TableColumn<S, T> col(String title, String prop, double w) {
        TableColumn<S, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        c.setPrefWidth(w);
        return c;
    }

    public Pane getView() { return root; }
}
