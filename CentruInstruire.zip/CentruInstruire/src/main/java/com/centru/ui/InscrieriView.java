package com.centru.ui;

import com.centru.dao.CursDAO;
import com.centru.dao.CursantDAO;
import com.centru.dao.InscriereDAO;
import com.centru.model.Curs;
import com.centru.model.Cursant;
import com.centru.model.Inscriere;
import com.centru.util.AlertHelper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class InscrieriView {

    private final InscriereDAO inscriereDAO = new InscriereDAO();
    private final CursantDAO   cursantDAO   = new CursantDAO();
    private final CursDAO      cursDAO      = new CursDAO();

    private final ObservableList<Inscriere> data         = FXCollections.observableArrayList();
    private final ObservableList<Cursant>   cursantiData = FXCollections.observableArrayList();
    private final ObservableList<Curs>      cursuriData  = FXCollections.observableArrayList();
    private final TableView<Inscriere> table = new TableView<>(data);

    private final ComboBox<Cursant> cbCursant = new ComboBox<>(cursantiData);
    private final ComboBox<Curs>    cbCurs    = new ComboBox<>(cursuriData);
    private final DatePicker dpData           = new DatePicker(LocalDate.now());
    private final ComboBox<String>  cbStatus  = new ComboBox<>();

    private Inscriere selected;
    private final BorderPane root = new BorderPane();

    public InscrieriView() {
        build();
        refresh();
    }

    @SuppressWarnings("unchecked")
    private void build() {
        TableColumn<Inscriere, Integer> colId     = col("ID",           "idInscriere",   55);
        TableColumn<Inscriere, String>  colCurs   = col("Cursant",      "numeCursant",  200);
        TableColumn<Inscriere, String>  colCursN  = col("Curs",         "denumireCurs", 180);
        TableColumn<Inscriere, String>  colData   = col("Data",         "dataInscriere", 110);
        TableColumn<Inscriere, String>  colStatus = col("Status Plată", "statusPlata",  120);
        TableColumn<Inscriere, Double>  colPret   = col("Preț (MDL)",   "pretCurs",     110);

        colPret.setCellFactory(tc -> new TableCell<>() {
            protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? null : String.format("%.2f", v));
            }
        });

        colStatus.setCellFactory(tc -> new TableCell<>() {
            protected void updateItem(String v, boolean empty) {
                super.updateItem(v, empty);
                if (empty || v == null) { setText(null); setStyle(""); return; }
                setText(v);
                setStyle(switch (v) {
                    case "Achitat"      -> "-fx-text-fill: #2ecc71; -fx-font-weight: bold;";
                    case "Anulat"       -> "-fx-text-fill: #e74c3c; -fx-font-weight: bold;";
                    default             -> "-fx-text-fill: #f39c12; -fx-font-weight: bold;";
                });
            }
        });

        table.getColumns().addAll(colId, colCurs, colCursN, colData, colStatus, colPret);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.getStyleClass().add("data-table");
        table.getSelectionModel().selectedItemProperty().addListener((obs, o, n) -> { selected = n; });

        // Filter by cursant
        ComboBox<Cursant> cbFilter = new ComboBox<>();
        cbFilter.setPromptText("Toți cursanții");
        cbFilter.setPrefWidth(220);
        Button btnFilter = new Button("🔍 Filtrează");
        btnFilter.getStyleClass().add("btn-search");
        Button btnReset = new Button("✕ Reset");
        btnReset.getStyleClass().add("btn-secondary");

        btnFilter.setOnAction(e -> {
            Cursant c = cbFilter.getValue();
            if (c == null) { refresh(); return; }
            try { data.setAll(inscriereDAO.getByCursant(c.getIdCursant())); }
            catch (SQLException ex) { AlertHelper.error("Eroare", ex.getMessage()); }
        });
        btnReset.setOnAction(e -> { cbFilter.setValue(null); refresh(); });

        HBox filterBar = new HBox(8, new Label("Cursant:"), cbFilter, btnFilter, btnReset);
        filterBar.setAlignment(Pos.CENTER_LEFT);
        filterBar.setPadding(new Insets(10, 12, 10, 12));
        filterBar.getStyleClass().add("search-bar");

        VBox tableBox = new VBox(0, filterBar, table);
        VBox.setVgrow(table, Priority.ALWAYS);

        // Form
        cbStatus.getItems().addAll("In asteptare", "Achitat", "Anulat");
        cbStatus.setValue("In asteptare");
        cbCursant.setPromptText("Selectați cursantul...");
        cbCursant.setPrefWidth(220);
        cbCurs.setPromptText("Selectați cursul...");
        cbCurs.setPrefWidth(220);
        cbStatus.setPrefWidth(220);

        GridPane form = new GridPane();
        form.setHgap(10); form.setVgap(10);
        form.setPadding(new Insets(16));
        form.add(label("Cursant *"),     0, 0); form.add(cbCursant, 1, 0);
        form.add(label("Curs *"),        0, 1); form.add(cbCurs,    1, 1);
        form.add(label("Data *"),        0, 2); form.add(dpData,    1, 2);
        form.add(label("Status Plată *"),0, 3); form.add(cbStatus,  1, 3);

        Button btnAdd    = new Button("➕ Înscrie");
        Button btnUpdate = new Button("✏️ Actualizează Status");
        Button btnDelete = new Button("🗑️ Anulează");
        Button btnClear  = new Button("🧹 Curăță");

        btnAdd.getStyleClass().add("btn-primary");
        btnUpdate.getStyleClass().add("btn-warning");
        btnDelete.getStyleClass().add("btn-danger");
        btnClear.getStyleClass().add("btn-secondary");

        btnAdd.setOnAction(e -> addInscriere());
        btnUpdate.setOnAction(e -> updateStatus());
        btnDelete.setOnAction(e -> deleteInscriere());
        btnClear.setOnAction(e -> clearForm());

        HBox buttons = new HBox(8, btnAdd, btnUpdate, btnDelete, btnClear);
        buttons.setWrap(true);

        Label formTitle = new Label("Gestionare Înscrieri");
        formTitle.getStyleClass().add("form-title");

        // Refresh comboboxes
        try {
            cursantiData.setAll(cursantDAO.getAll());
            cursuriData.setAll(cursDAO.getAll());
            cbFilter.setItems(cursantiData);
        } catch (SQLException e) { AlertHelper.error("Eroare", e.getMessage()); }

        VBox formBox = new VBox(12, formTitle, form, buttons);
        formBox.setPadding(new Insets(12));
        formBox.getStyleClass().add("form-panel");
        formBox.setPrefWidth(300);

        root.setCenter(tableBox);
        root.setRight(formBox);
    }

    private void refresh() {
        try { data.setAll(inscriereDAO.getAll()); }
        catch (SQLException e) { AlertHelper.error("Eroare", e.getMessage()); }
    }

    private void addInscriere() {
        if (cbCursant.getValue() == null) { AlertHelper.error("Validare", "Selectați un cursant!"); return; }
        if (cbCurs.getValue() == null)    { AlertHelper.error("Validare", "Selectați un curs!"); return; }
        if (dpData.getValue() == null)    { AlertHelper.error("Validare", "Selectați data!"); return; }
        try {
            int idC = cbCursant.getValue().getIdCursant();
            int idCu = cbCurs.getValue().getIdCurs();
            if (inscriereDAO.exists(idC, idCu)) {
                AlertHelper.error("Validare", "Cursantul este deja înscris la acest curs!"); return;
            }
            Inscriere ins = new Inscriere(0, idC, idCu, dpData.getValue(), cbStatus.getValue());
            inscriereDAO.insert(ins);
            clearForm(); refresh();
        } catch (SQLException e) { AlertHelper.error("Eroare BD", e.getMessage()); }
    }

    private void updateStatus() {
        if (selected == null) { AlertHelper.error("Selecție", "Selectați o înscriere!"); return; }
        if (cbStatus.getValue() == null) { AlertHelper.error("Validare", "Selectați statusul!"); return; }
        try {
            inscriereDAO.updateStatus(selected.getIdInscriere(), cbStatus.getValue());
            refresh();
        } catch (SQLException e) { AlertHelper.error("Eroare BD", e.getMessage()); }
    }

    private void deleteInscriere() {
        if (selected == null) { AlertHelper.error("Selecție", "Selectați o înscriere!"); return; }
        if (!AlertHelper.confirm("Confirmare", "Anulați înscrierea cursantului \"" + selected.getNumeCursant() + "\" la cursul \"" + selected.getDenumireCurs() + "\"?")) return;
        try { inscriereDAO.delete(selected.getIdInscriere()); refresh(); }
        catch (SQLException e) { AlertHelper.error("Eroare BD", e.getMessage()); }
    }

    private void clearForm() {
        selected = null;
        cbCursant.setValue(null); cbCurs.setValue(null);
        dpData.setValue(LocalDate.now()); cbStatus.setValue("In asteptare");
        table.getSelectionModel().clearSelection();
    }

    private <S, T> TableColumn<S, T> col(String title, String prop, double w) {
        TableColumn<S, T> c = new TableColumn<>(title);
        c.setCellValueFactory(new PropertyValueFactory<>(prop));
        c.setPrefWidth(w);
        return c;
    }

    private Label label(String t) {
        Label l = new Label(t);
        l.getStyleClass().add("form-label");
        return l;
    }

    public Pane getView() { return root; }
}
