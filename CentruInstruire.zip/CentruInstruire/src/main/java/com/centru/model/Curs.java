package com.centru.model;

public class Curs {
    private int idCurs;
    private String denumire;
    private String formator;
    private double pret;
    private int durataZile;

    public Curs() {}

    public Curs(int idCurs, String denumire, String formator, double pret, int durataZile) {
        this.idCurs = idCurs;
        this.denumire = denumire;
        this.formator = formator;
        this.pret = pret;
        this.durataZile = durataZile;
    }

    public int getIdCurs()              { return idCurs; }
    public void setIdCurs(int v)        { this.idCurs = v; }

    public String getDenumire()         { return denumire; }
    public void setDenumire(String v)   { this.denumire = v; }

    public String getFormator()         { return formator; }
    public void setFormator(String v)   { this.formator = v; }

    public double getPret()             { return pret; }
    public void setPret(double v)       { this.pret = v; }

    public int getDurataZile()          { return durataZile; }
    public void setDurataZile(int v)    { this.durataZile = v; }

    @Override
    public String toString() {
        return denumire + " - " + formator + " (" + durataZile + " zile)";
    }
}
