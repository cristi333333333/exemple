package com.centru.model;

import java.time.LocalDate;

public class Inscriere {
    private int idInscriere;
    private int idCursant;
    private int idCurs;
    private LocalDate dataInscriere;
    private String statusPlata;

    // For display (JOIN fields)
    private String numeCursant;
    private String denumireCurs;
    private double pretCurs;

    public Inscriere() {}

    public Inscriere(int idInscriere, int idCursant, int idCurs, LocalDate dataInscriere, String statusPlata) {
        this.idInscriere = idInscriere;
        this.idCursant = idCursant;
        this.idCurs = idCurs;
        this.dataInscriere = dataInscriere;
        this.statusPlata = statusPlata;
    }

    public int getIdInscriere()               { return idInscriere; }
    public void setIdInscriere(int v)         { this.idInscriere = v; }

    public int getIdCursant()                 { return idCursant; }
    public void setIdCursant(int v)           { this.idCursant = v; }

    public int getIdCurs()                    { return idCurs; }
    public void setIdCurs(int v)              { this.idCurs = v; }

    public LocalDate getDataInscriere()       { return dataInscriere; }
    public void setDataInscriere(LocalDate v) { this.dataInscriere = v; }

    public String getStatusPlata()            { return statusPlata; }
    public void setStatusPlata(String v)      { this.statusPlata = v; }

    public String getNumeCursant()            { return numeCursant; }
    public void setNumeCursant(String v)      { this.numeCursant = v; }

    public String getDenumireCurs()           { return denumireCurs; }
    public void setDenumireCurs(String v)     { this.denumireCurs = v; }

    public double getPretCurs()               { return pretCurs; }
    public void setPretCurs(double v)         { this.pretCurs = v; }
}
