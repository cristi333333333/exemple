package com.centru.model;

public class Cursant {
    private int idCursant;
    private String nume;
    private String prenume;
    private String telefon;
    private String email;

    public Cursant() {}

    public Cursant(int idCursant, String nume, String prenume, String telefon, String email) {
        this.idCursant = idCursant;
        this.nume = nume;
        this.prenume = prenume;
        this.telefon = telefon;
        this.email = email;
    }

    public int getIdCursant()           { return idCursant; }
    public void setIdCursant(int id)    { this.idCursant = id; }

    public String getNume()             { return nume; }
    public void setNume(String v)       { this.nume = v; }

    public String getPrenume()          { return prenume; }
    public void setPrenume(String v)    { this.prenume = v; }

    public String getTelefon()          { return telefon; }
    public void setTelefon(String v)    { this.telefon = v; }

    public String getEmail()            { return email; }
    public void setEmail(String v)      { this.email = v; }

    public String getNumeComplet()      { return nume + " " + prenume; }

    @Override
    public String toString() {
        return getNumeComplet() + " (" + email + ")";
    }
}
