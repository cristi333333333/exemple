package com.centru.model;

public class RaportRow {
    private String numeComplet;
    private int nrInscrieri;
    private double sumaAchitata;

    public RaportRow(String numeComplet, int nrInscrieri, double sumaAchitata) {
        this.numeComplet = numeComplet;
        this.nrInscrieri = nrInscrieri;
        this.sumaAchitata = sumaAchitata;
    }

    public String getNumeComplet()      { return numeComplet; }
    public int getNrInscrieri()         { return nrInscrieri; }
    public double getSumaAchitata()     { return sumaAchitata; }
}
