package com.centru;

import com.centru.ui.MainController;
import com.centru.util.DatabaseConnection;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        try {
            // Test connection early
            DatabaseConnection.getConnection();
        } catch (Exception e) {
            javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.ERROR);
            alert.setTitle("Eroare conexiune");
            alert.setHeaderText("Nu s-a putut conecta la baza de date MySQL!");
            alert.setContentText("Verificati:\n1. MySQL pornit\n2. Baza de date 'centru_instruire' exista\n3. Credentialele in DatabaseConnection.java\n\nDetalii: " + e.getMessage());
            alert.showAndWait();
            Platform.exit();
            return;
        }

        MainController controller = new MainController();
        Scene scene = new Scene(controller.getView(), 1100, 700);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        primaryStage.setTitle("Centru de Instruire - Sistem de Evidenta");
        primaryStage.setScene(scene);
        primaryStage.setMinWidth(900);
        primaryStage.setMinHeight(600);
        primaryStage.show();
    }

    @Override
    public void stop() {
        DatabaseConnection.closeConnection();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
